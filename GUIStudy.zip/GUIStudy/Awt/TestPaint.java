package GUIStudy.Awt;

import java.awt.*;

public class TestPaint {
    public static void main(String[] args) {
            new MyPaint().LoadFrame();
    }
}

class MyPaint extends Frame
{
    public void LoadFrame()
    {
         setBounds(200,300,600,500);
         TestFrame.WindowsClose(this);
         setVisible(true);
    }
    @Override
    public void paint(Graphics g) {
       // super.paint(g);
        g.setColor(Color.red);
        g.drawOval(100,100,100,100);
        g.fillOval(200,210,100,100);

        g.setColor(Color.blue);
        g.fillRect(205,100,100,100);
    }
}
