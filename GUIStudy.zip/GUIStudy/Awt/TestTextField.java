package GUIStudy.Awt;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TestTextField {
    public static void main(String[] args) {
          new MyFrameText();
    }
}

class MyFrameText extends Frame
{
   public MyFrameText()
   {
       //setBounds(200,300,400,500);
       setSize(500,600);
       TextField Tf_text=new TextField();
       add(Tf_text);

       MyAcListener Malt = new MyAcListener();
       //监听
       Tf_text.addActionListener(Malt);
       TestFrame.WindowsClose(this);
       //设置替换编码
       Tf_text.setEchoChar('*');

       setVisible(true);
       pack();//自适应
   }

}

class MyAcListener implements ActionListener
{

    @Override
    public void actionPerformed(ActionEvent e) {
        TextField Tfm=(TextField)e.getSource();
        System.out.println(Tfm.getText());
        Tfm.setText("");
    }
}