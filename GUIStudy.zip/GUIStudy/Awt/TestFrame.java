package GUIStudy.Awt;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestFrame {
    public static void main(String[] args) {
        Frame p=new Frame();
        Button btn1=new Button("output");//awt 对中文支持不太好，用swing jbutton
        MyActionListenerOne Mal=new MyActionListenerOne();
        btn1.addActionListener(Mal);

        p.add(btn1,BorderLayout.CENTER);
        p.pack();
        WindowsClose(p);
        p.setVisible(true);

    }
//窗口关闭
    public static void WindowsClose(Frame frame)
    {
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
//事件监听
class MyActionListenerOne implements ActionListener
{
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("aaa");
    }
}
