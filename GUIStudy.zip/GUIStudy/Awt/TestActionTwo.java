package GUIStudy.Awt;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TestActionTwo {
    public static void main(String[] args) {
        Frame p=new Frame("开始-停止");
        p.setBackground(new Color(76, 88, 219));
        p.setSize(200,300);
        Button btn1= new Button("start");
        Button btn2=new Button("stop");
        btn1.setActionCommand("btn1-start");

        MyActionListenerTwo Malt=new MyActionListenerTwo();
        btn1.addActionListener(Malt);
        btn2.addActionListener(Malt);

        p.add(btn1,BorderLayout.NORTH);
        p.add(btn2,BorderLayout.SOUTH);
        TestFrame.WindowsClose(p);
        p.setVisible(true);
    }
}

class MyActionListenerTwo implements ActionListener
{
    @Override
    public void actionPerformed(ActionEvent e) {
       System.out.println("按钮被点击了：msg=" +e.getActionCommand());
    }
}
