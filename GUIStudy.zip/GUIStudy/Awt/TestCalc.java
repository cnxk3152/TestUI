package GUIStudy.Awt;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TestCalc {
    public static void main(String[] args) {
       //   new Calculator();
       // new CalculatorOne().loadFrame();
        new CalculatorTwo().loadFrame();
    }
}

//计算器类
class Calculator extends Frame
{
    public Calculator()
    {
      //3个文本械
        TextField tf1 = new TextField(10);
        TextField tf2 = new TextField(10);
        TextField tf3 = new TextField(20);
      //1个按钮
        Button btn = new Button("=");
      //1个标签
        Label lb = new Label("+");

        //btn.addActionListener(new MyCalculatorListener(tf1,tf2,tf3));
        //btn.addActionListener(new MyCalculatorListener(this));

        //布局
        setLayout(new FlowLayout());

        add(tf1);
        add(lb);
        add(tf2);
        add(btn);
        add(tf3);

        pack();
        TestFrame.WindowsClose(this);
        setVisible(true);
    }
}

class CalculatorOne extends Frame
{
    TextField tf1,tf2,tf3;

    public void loadFrame()
    {
        //3个文本械
         tf1 = new TextField(10);
         tf2 = new TextField(10);
         tf3 = new TextField(20);
        //1个按钮
        Button btn = new Button("=");
        //1个标签
        Label lb = new Label("+");

        btn.addActionListener(new MyCalculatorListener(this));

        //布局
        setLayout(new FlowLayout());

        add(tf1);
        add(lb);
        add(tf2);
        add(btn);
        add(tf3);

        pack();
        TestFrame.WindowsClose(this);
        setVisible(true);
    }
}

class CalculatorTwo extends Frame
{
    TextField tf1,tf2,tf3;

    public void loadFrame()
    {
        //3个文本械
        tf1 = new TextField(10);
        tf2 = new TextField(10);
        tf3 = new TextField(20);
        //1个按钮
        Button btn = new Button("=");
        //1个标签
        Label lb = new Label("+");

        btn.addActionListener(new MyCalculatorListenerOne());

        //布局
        setLayout(new FlowLayout());

        add(tf1);
        add(lb);
        add(tf2);
        add(btn);
        add(tf3);

        pack();
        TestFrame.WindowsClose(this);
        setVisible(true);
    }
   //内部类
   private class MyCalculatorListenerOne implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {

            int n1=Integer.parseInt(tf1.getText());
            int n2=Integer.parseInt(tf2.getText());
            tf3.setText(""+(n1+n2));
            tf1.setText("");
            tf2.setText("");
        }
    }
}
//监听器
class MyCalculatorListener implements ActionListener
{
   //获取三个变量 1
//    private TextField tf1,tf2,tf3;
//    public MyCalculatorListener(TextField tf1,TextField tf2,TextField tf3)
//    {
//        this.tf1=tf1;
//        this.tf2=tf2;
//        this.tf3=tf3;
//    }
    //2
    CalculatorOne My_Calc=null;
    public MyCalculatorListener(CalculatorOne cal)
    {
        My_Calc=cal;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        /***
         * 1
         */
       //获得相加数
//       int n1=Integer.parseInt(tf1.getText());
//       int n2=Integer.parseInt(tf2.getText());
       //输入出值
       // tf3.setText(""+(n1+n2));
       //清除相加数输入
//        tf1.setText("");
//        tf2.setText("");

        /**
         * 2
         */
        int n1=Integer.parseInt(My_Calc.tf1.getText());
        int n2=Integer.parseInt(My_Calc.tf2.getText());
        My_Calc.tf3.setText(""+(n1+n2));
        My_Calc.tf1.setText("");
        My_Calc.tf2.setText("");
    }
}