package GUIStudy.Awt;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestKeyListener {
    public static void main(String[] args) {
       new KeyFrame();
    }
}

class KeyFrame extends Frame
{
    public KeyFrame()
    {
        setBounds(100,100,300,400);
        setVisible(true);
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
               int keycode=e.getKeyCode();
                System.out.println(keycode);
               if(keycode ==KeyEvent.VK_E)
                   System.out.println("按E了");
            }
        });

        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

}