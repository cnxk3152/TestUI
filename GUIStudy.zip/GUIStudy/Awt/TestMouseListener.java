package GUIStudy.Awt;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;

public class TestMouseListener {
    public static void main(String[] args) {
      new MyMouseFrame("DrawGraphics");
    }
}

class MyMouseFrame extends Frame
{
   ArrayList points;
   public MyMouseFrame(String title)
   {
       super(title);
       setBounds(200,300,600,500);
       TestFrame.WindowsClose(this);

       points=new ArrayList<>();
       setVisible(true);

       this.addMouseListener(new MyMouseListener());


   }

    @Override
    public void paint(Graphics g) {
        Iterator iterator = points.iterator();
        while (iterator.hasNext())
        {
           Point point=(Point)iterator.next();
           g.setColor(Color.blue);
           g.fillOval(point.x,point.y,10,10);
        }
    }

    public void addPaint(Point point)
    {
      points.add(point);
    }

    private class MyMouseListener extends MouseAdapter
    {
        @Override
        public void mousePressed(MouseEvent e) {
           MyMouseFrame myMouseFrame= (MyMouseFrame) e.getSource();
           myMouseFrame.addPaint( new Point(e.getX(),e.getY()));

           myMouseFrame.repaint();//每次点击重画
        }
    }
}