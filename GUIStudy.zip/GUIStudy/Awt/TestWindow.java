package GUIStudy.Awt;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestWindow {
    public static void main(String[] args) {
        new WindowFrame();
    }

}

class WindowFrame extends Frame
{
    public WindowFrame(){
        setBackground(Color.blue);
        setBounds(100,100,500,600);
        setVisible(true);
        //addWindowListener(new MyWindowListener());
        this.addWindowListener(new WindowAdapter() {//匿名内部类

            @Override
            public void windowClosing(WindowEvent e) {
                System.out.println("窗口正关闭");
                System.exit(0);
            }

            @Override
            public void windowActivated(WindowEvent e) {
                WindowFrame windowFrame=(WindowFrame) e.getSource();
                windowFrame.setTitle("窗口激活");
                System.out.println("窗口激活");
            }
        });
    }
}