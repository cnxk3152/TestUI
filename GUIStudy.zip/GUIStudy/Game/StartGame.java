package GUIStudy.Game;

import GUIStudy.Swing.JFrameDemo;
import com.sun.javafx.logging.JFRInputEvent;

import javax.swing.*;
import java.awt.*;

public class StartGame {
    public static void main(String[] args) {
        JFrame jFrame = new JFrame();

        jFrame.setBounds(10,10,900,720);
        jFrame.setResizable(false);//不可变
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        jFrame.setTitle("Game");
        jFrame.setIconImage(DataCenter.body.getImage());

        jFrame.add(new GamePanel());

        jFrame.setVisible(true);
    }
}
