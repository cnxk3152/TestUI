package GUIStudy.Game;

import javax.swing.*;
import java.net.URL;

public class DataCenter {

    //相对路径 tx.png
    //绝对路径 /相当于当前项目
    public static URL headerURL=DataCenter.class.getResource("Statics/header.png");
    public static ImageIcon header=new ImageIcon(headerURL);

    public static URL upURL=DataCenter.class.getResource("Statics/up.png");
    public static URL downURL=DataCenter.class.getResource("Statics/down.png");
    public static URL leftURL=DataCenter.class.getResource("Statics/left.png");
    public static URL rightURL=DataCenter.class.getResource("Statics/right.png");
    public static URL bodyURL=DataCenter.class.getResource("Statics/body.png");
    public static URL foodURL=DataCenter.class.getResource("Statics/food.png");

    public static ImageIcon up=new ImageIcon(upURL);
    public static ImageIcon down=new ImageIcon(downURL);
    public static ImageIcon left=new ImageIcon(leftURL);
    public static ImageIcon right=new ImageIcon(rightURL);
    public static ImageIcon body=new ImageIcon(bodyURL);
    public static ImageIcon food=new ImageIcon(foodURL);

}
