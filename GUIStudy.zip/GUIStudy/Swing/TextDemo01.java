package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;

public class TextDemo01 extends JFrame {
    public TextDemo01() {
        Container container = this.getContentPane();

        JTextField jTextField = new JTextField("hello");
        JTextField jTextField2 = new JTextField("world",20);

        JPanel jPanel = new JPanel();
        jPanel.add(jTextField);
        jPanel.add(jTextField2);

        container.add(jPanel);

        this.setVisible(true);
        this.setBounds(100,100,300,350);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new TextDemo01();
    }
}
