package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class TomboBoxDemo02 extends JFrame {
    public TomboBoxDemo02() {
        Container container = this.getContentPane();

        //下拉菜单
        //String[] contents={"1","2","3","4"};
        Vector contents=new Vector();

        JList jList = new JList(contents);
        contents.add("一");
        contents.add("二");
        contents.add("三");
        contents.add("四");

        JPanel jPanel = new JPanel();
        jPanel.add(jList);

        container.add(jPanel);
        //container.add(jList);
        this.setVisible(true);
        this.setBounds(100,100,300,350);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new TomboBoxDemo02();
    }
}
