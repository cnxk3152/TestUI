package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.util.concurrent.BrokenBarrierException;

public class JButtonDemo02 extends JFrame {
    public JButtonDemo02() {
        Container contentPane = this.getContentPane();

        URL url = JButtonDemo.class.getResource("tx.png");
        Icon icon=new ImageIcon(url);

        JRadioButton jRadioButton1 = new JRadioButton("单选1");
        JRadioButton jRadioButton2 = new JRadioButton("单选2");
        JRadioButton jRadioButton3 = new JRadioButton("单选3");

        //去掉下列分组，单选变多选
        ButtonGroup buttonGroup = new ButtonGroup();//单选只能选一个，分组
        buttonGroup.add(jRadioButton1);
        buttonGroup.add(jRadioButton2);
        buttonGroup.add(jRadioButton3);

        contentPane.add(jRadioButton1,BorderLayout.NORTH);
        contentPane.add(jRadioButton2,BorderLayout.CENTER);
        contentPane.add(jRadioButton3,BorderLayout.SOUTH);

        this.setVisible(true);
        this.setBounds(100,100,300,350);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new JButtonDemo02();
    }
}
