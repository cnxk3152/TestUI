package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DialogDemo extends JFrame {

    public DialogDemo()
    {
        this.setSize(300,400);

        this.setVisible(true);
        this .setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        Container contentPane = this.getContentPane();//获得容器
        contentPane.setLayout(null);//绝对布局

        JButton jButton = new JButton("弹出一个对话框");
        jButton.setBounds(30,30,200,50);

        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MyDialogDemo();
            }
        });

        contentPane.add(jButton);
    }

    public static void main(String[] args) {
        new DialogDemo();
    }
}

class MyDialogDemo extends JDialog
{
    public MyDialogDemo()
    {

        this.setVisible(true);
        this.setBounds(200,200,300,300);
        this.setTitle("DiglogDemo");

        JButton btn=new JButton("新按钮");
        btn.setBounds(20,20,100,50);
        JLabel label=new JLabel("弹出Dialog");
        label.setBounds(50,100,100,50);
        Container contentPane = this.getContentPane();
        //contentPane.setLayout(new GridLayout(2,1));//绝对定位布局,参数为null时,add添加的东西有得不显示
        contentPane.setLayout(null);//选用此布局时，需要调协在小长宽高

        contentPane.setBackground(Color.blue);
        contentPane.add(btn);
        //contentPane.add(new JLabel("弹出Dialog"));//!!布局为null时，显示不出来
        contentPane.add(label);
    }
}