package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

class ImageIconDemo extends JFrame {
    public ImageIconDemo() {
        JLabel jLabel = new JLabel("ImageIcon");
        URL url=ImageIconDemo.class.getResource("tx.png");

        ImageIcon imageIcon=new ImageIcon(url);

        jLabel.setIcon(imageIcon);
        jLabel.setHorizontalAlignment(SwingConstants.CENTER);

        Container contentPane = this.getContentPane();
        contentPane.add(jLabel);

        setVisible(true);
        setBounds(100,100,200,200);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new ImageIconDemo();
    }
}
