package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;

public class TextDemo02 extends JFrame {

    public TextDemo02() {
        Container container = this.getContentPane();

        JPasswordField jPasswordField = new JPasswordField(20);
        jPasswordField.setEchoChar('*');


        JPanel jPanel = new JPanel();
        jPanel.add(jPasswordField);


        container.add(jPanel);

        this.setVisible(true);
        this.setBounds(100,100,300,350);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
       new TextDemo02();
    }
}
