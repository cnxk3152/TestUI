package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;

public class JScrollPanel extends JFrame {
    public JScrollPanel()
    {
        Container contentPane = this.getContentPane();

        JTextArea jTextArea = new JTextArea(20,50);
        jTextArea.setText("来了啊，老弟！！！！");

        JScrollPane jScrollPane = new JScrollPane(jTextArea);



        contentPane.add(jScrollPane);


        this.setVisible(true);
        this.setBounds(100,100,300,350);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new JScrollPanel();
    }
}
