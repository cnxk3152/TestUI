package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;

public class JFrameDemo02 {
    public static void main(String[] args) {
     new MyJFrame().init();
    }
}

class MyJFrame extends JFrame
{
   public void init()
   {
       this.setBounds(100,100,200,300);
       this.setVisible(true);
       JLabel label=new JLabel("来了，老弟");
       label.setHorizontalAlignment(SwingConstants.CENTER);
       this.add(label);
       //获得一个容器
       Container contentPane = this.getContentPane();
       contentPane.setBackground(Color.blue);

       this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
   }
}