package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;

public class JFrameDemo {
    public void init()
    {
        JFrame jf = new JFrame("这个一个JFrame窗口");
        jf.setVisible(true);
        jf.setBounds(100,100,300,400);
        jf.setBackground(Color.BLUE);
        JLabel jLabel = new JLabel("JLabel");

        jf.add(jLabel);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
          new JFrameDemo().init();
    }
}
