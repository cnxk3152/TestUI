package GUIStudy.Swing;

import jdk.internal.org.objectweb.asm.tree.MultiANewArrayInsnNode;

import javax.swing.*;
import java.awt.*;

public class TomboBoxDemo extends JFrame {
    public TomboBoxDemo() {
        Container container = this.getContentPane();

        //下拉菜单
        JComboBox status = new JComboBox();
        status.addItem(null);
        status.addItem("正在热映");
        status.addItem("已下架");
        status.addItem("即将上映");
        status.addItem("预告");

        JPanel jPanel = new JPanel();
        jPanel.add(status);

        container.add(jPanel);
        //container.add(status);
        this.setVisible(true);
        this.setBounds(100,100,300,350);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new TomboBoxDemo();
    }
}
