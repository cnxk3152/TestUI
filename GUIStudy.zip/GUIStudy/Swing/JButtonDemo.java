package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class JButtonDemo extends JFrame {

    public JButtonDemo(){
        Container contentPane = this.getContentPane();
        URL url = JButtonDemo.class.getResource("tx.png");
        Icon icon=new ImageIcon(url);

        JButton jButton = new JButton();
        jButton.setBounds(10,10,100,50);
        jButton.setIcon(icon);
        jButton.setToolTipText("图片按钮");

        contentPane.setLayout(null);
        contentPane.add(jButton);

        setVisible(true);
        setBounds(100,100,300,300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new JButtonDemo();
    }
}
