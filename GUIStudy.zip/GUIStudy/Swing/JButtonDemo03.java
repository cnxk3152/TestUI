package GUIStudy.Swing;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class JButtonDemo03 extends JFrame {
    public JButtonDemo03() {
        Container contentPane = this.getContentPane();
        URL url = JButtonDemo.class.getResource("tx.png");
        Icon icon=new ImageIcon(url);

        //多选
        JCheckBox jCheckBox1 = new JCheckBox("多选01");
        JCheckBox jCheckBox2 = new JCheckBox("多选02");
        JCheckBox jCheckBox3 = new JCheckBox("多选03");
        JCheckBox jCheckBox4 = new JCheckBox("多选04");

        //多选按钮加入下列分组后，变成单选
//        ButtonGroup buttonGroup=new ButtonGroup();
//        buttonGroup.add(jCheckBox1);
//        buttonGroup.add(jCheckBox2);
//        buttonGroup.add(jCheckBox3);

        contentPane.add(jCheckBox1,BorderLayout.NORTH);
        contentPane.add(jCheckBox2,BorderLayout.CENTER);
        contentPane.add(jCheckBox3,BorderLayout.SOUTH);

        this.setVisible(true);
        this.setBounds(100,100,300,350);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new JButtonDemo03();
    }
}
