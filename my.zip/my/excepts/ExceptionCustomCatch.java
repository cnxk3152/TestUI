package my.excepts;

/**
 * 自定义 custom
 * 通过继承 Exception 来实现自定义异常
 */
class WrongInputException extends Exception {  // 自定义的类
    WrongInputException(String s) {
        super(s);
    }
}
class MyInput {
    void method() throws WrongInputException {
        throw new WrongInputException("Wrong input"); // 抛出自定义的类
    }
}
public class ExceptionCustomCatch {
    public static void main(String[] args){
        try {
            new MyInput().method();
        }
        catch(WrongInputException wie) {
            System.out.println(wie.getMessage());
        }
    }
}
