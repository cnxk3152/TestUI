多个 Multiple
处理 handle
重载 heavy load /overloading
覆盖 cover /override
异常 abnormal
例外 Exception
链试 Chain test
自定义 custom
扩容 Expansion