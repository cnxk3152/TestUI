package my.arrays;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 通过 List 类的 Arrays.toString () 方法和 List 类的 list.Addall(array1.asList(array2) 方法将两个数组合并为一个数组：
 *
 * 网上有java连接数组的方法，然而那些都是针对泛型的，偏偏字节数组以及其他几个原始数据类型的数组不属于泛型方法能操控的，
 * 于是所有使用泛型的连接数组的方法都失效，只剩下System.arraycopy()这一个可以用的了，然而这个函数参数很多，用起来并
 * 没有那么方便，而且每次只能连接两个数组，太麻烦了。
 *
 * 可以用JDK提供的ByteArrayOutputStream搞定这个麻烦。只需要提前计算好最终数组的大小，分配好数组空间之后，刷唰唰往里边按顺序写入想要连接的数组就好了。
 */
public class combinationArray {
    public static void main(String args[]) throws IOException {  //throws IOException 这个因为其它调用方法有抛出异常需要
        String a[] = { "A", "E", "I" };
        String b[] = { "O", "U" };
        List list = new ArrayList(Arrays.asList(a));
        list.addAll(Arrays.asList(b));
        Object[] c = list.toArray();
        System.out.println(Arrays.toString(c));
       // byte[] aByte=new BigInteger("0123456").toByteArray();
       // getStrunctureBytes(aByte);
       // System.out.println(aByte.toString());
        System.out.println("ConcatArray:");
        concatArrays();
    }

    //实际上不会因为数组读写而抛出异常
    static byte[] getStrunctureBytes(byte[] data) throws IOException {
        byte[] groupUID=new BigInteger("0123").toByteArray();
        byte[] sn=new BigInteger("456").toByteArray();
        byte[] bodySize=new BigInteger("789").toByteArray();

        //上边三个字节数组用16字节空间+data的大小，以此大小分配缓冲区避免反复分配和复制内存
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(16+data.length);
        byteArrayOutputStream.write(groupUID);
        byteArrayOutputStream.write(sn);
        byteArrayOutputStream.write(bodySize);
        byteArrayOutputStream.write(data);
        byteArrayOutputStream.flush();//字节数组流的冲刷其实没有用，但是使用流的时候及时冲刷是好习惯

        return byteArrayOutputStream.toByteArray();
    }

    static void concatArrays()
    {
        int[] myNumbers=new int[]{1,2,3,4};
        int[] yourNumbers=new int[]{5,6,7};
        int[] theirNumbers=new int[]{8,9,0};

        //按需要分配buffer
        IntBuffer intBuffer = IntBuffer.allocate(myNumbers.length+yourNumbers.length+theirNumbers.length);

        //放入到buffer
        intBuffer.put(myNumbers);
        intBuffer.put(yourNumbers);
        intBuffer.put(theirNumbers);

        //得到合并后的数组
        int[] allNumber = intBuffer.array();

        //显示合并后的数组
        for (int i :allNumber ) {
            System.out.print(i);
            System.out.print(", ");
        }


        //各种数据原始类型都有buffer可用，非常方便
        LongBuffer longBuffer = LongBuffer.allocate(10);
        DoubleBuffer doubleBuffer = DoubleBuffer.allocate(10);
        FloatBuffer floatBuffer = FloatBuffer.allocate(10);
        ByteBuffer byteBuffer = ByteBuffer.allocate(10);
        ShortBuffer shortBuffer = ShortBuffer.allocate(10);
        CharBuffer charBuffer = CharBuffer.allocate(10);
    }
}
