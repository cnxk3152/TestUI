package my.arrays;

import java.util.HashSet;
import java.util.Set;

/**
 * 使用 union ()方法来计算两个数组的并集
 * 1、并集
 * 对于两个给定集合A、B，由两个集合所有元素构成的集合，叫做A和B的并集。
 * 记作：AUB  读作“A并B”
 * 例： {3,5}U{2,3,4,6}= {2,3,4,5,6}
 * 2、交集
 * 对于两个给定集合A、B，由属于A又属于B的所有元素构成的集合，叫做A和B的交集。
 * 记作： A∩B   读作“A交B”
 * 例： A={1,2,3,4,5}，B={3,4,5,6,8}，A∩B={3,4,5}
 * 3、差集
 * 记A，B是两个集合，则所有属于A且不属于B的元素构成的集合，叫做集合A减集合B(或集合A与集合B之差)，类似地，对于集合A、B，把集合{x∣x∈A,且x∉B}叫做A与B的差集。
 * 记作：B-A
 * 4、补集
 * 一般地，设S是一个集合，A是S的一个子集，由S中所有不属于A的元素组成的集合，叫做子集A在S中的绝对补集。
 * 记作：∁UA，包括三层含义：
 * 1）A是U的一个子集，即A⊊U;
 * 2）∁UA表示一个集合，且∁UA⊊U;
 * 3）∁UA是由U中所有不属于A的元素组成的集合，∁UA与A没有公共元素，U中的元素分布在这两个集合中。
 * 举例：全集为｛1,2,3,4,5｝ 那么｛1,2｝的补集就是｛3,4,5｝
 * 1、并集
 * 对于两个给定集合A、B，由两个集合所有元素构成的集合，叫做A和B的并集。
 * 记作：AUB  读作“A并B”
 * 例： {3,5}U{2,3,4,6}= {2,3,4,5,6}
 * 2、交集
 * 对于两个给定集合A、B，由属于A又属于B的所有元素构成的集合，叫做A和B的交集。
 * 记作： A∩B   读作“A交B”
 * 例： A={1,2,3,4,5}，B={3,4,5,6,8}，A∩B={3,4,5}
 * 3、差集
 * 记A，B是两个集合，则所有属于A且不属于B的元素构成的集合，叫做集合A减集合B(或集合A与集合B之差)，类似地，对于集合A、B，把集合{x∣x∈A,且x∉B}叫做A与B的差集。
 * 记作：B-A
 * 4、补集
 * 一般地，设S是一个集合，A是S的一个子集，由S中所有不属于A的元素组成的集合，叫做子集A在S中的绝对补集。
 * 记作：∁UA，包括三层含义：
 * 1）A是U的一个子集，即A⊊U;
 * 2）∁UA表示一个集合，且∁UA⊊U;
 * 3）∁UA是由U中所有不属于A的元素组成的集合，∁UA与A没有公共元素，U中的元素分布在这两个集合中。
 * 举例：全集为｛1,2,3,4,5｝ 那么｛1,2｝的补集就是｛3,4,5｝
 */
public class UnionSetArrays {
    public static void main(String[] args) throws Exception {
        String[] arr1 = { "1", "2", "3" };
        String[] arr2 = { "4", "5", "6" };
        String[] result_union = union(arr1, arr2);
        System.out.println("并集的结果如下：");

        for (String str : result_union) {
            System.out.println(str);
        }
    }

    // 求两个字符串数组的并集，利用set的元素唯一性
    public static String[] union(String[] arr1, String[] arr2) {
        Set<String> set = new HashSet<String>();

        for (String str : arr1) {
            set.add(str);
        }

        for (String str : arr2) {
            set.add(str);
        }

        String[] result = {  };

        return set.toArray(result);
    }
}
