package my.arrays;

import java.util.Arrays;
import java.util.Collections;

/**
 * 使用自定义的 reverse 方法将数组进行反转
 */
public class reverseArray {
    /* 反转数组*/
    static void reverse(int a[], int n)
    {
        int[] b = new int[n];
        int j = n;
        for (int i = 0; i < n; i++) {
            b[j - 1] = a[i];
            j = j - 1;
        }

        /*输入反转数组*/
        System.out.println("反转后数组是: \n");
        for (int k = 0; k < n; k++) {
            System.out.println(b[k]);
        }
    }
    //================method2=========
    /* 创建方法，第一个与最后一个交互，第二个与倒数第二个交换，以此类推*/
    static void reverseMe(int a[], int n)
    {
        int i, k, t;
        for (i = 0; i < n / 2; i++) {
            t = a[i];
            a[i] = a[n - i - 1];
            a[n - i - 1] = t;
        }

        System.out.println("反转后的数组是: \n");
        for (k = 0; k < n; k++) {
            System.out.println(a[k]);
        }
    }

    //====================method3====================
    /* 使用 java.util.Arrays.asList(array) 方法 integer 是对象引用*/
    static void reverseMeTwo(Integer a[])
    {
        Collections.reverse(Arrays.asList(a));
        System.out.println(Arrays.asList(a));
    }


    public static void main(String[] args)
    {
        int [] arr = {10, 20, 30, 40, 50};
        reverse(arr, arr.length);

        int[] arrMe={100,200,300,400,500};
        reverseMe(arrMe,arrMe.length);

        Integer[] arrMeTwo={1,2,3,4,5};
        reverseMeTwo(arrMeTwo);
    }


}
