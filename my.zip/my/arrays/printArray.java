package my.arrays;

import java.util.ArrayList;
import java.util.Iterator;

public class printArray {
    public static void main(String[] args){
        String[] runoobs = new String[3];
        runoobs[0] = "菜鸟教程";
        runoobs[1] = "菜鸟工具";
        runoobs[2] = "菜鸟笔记";
        for (int i = 0; i < runoobs.length; i++){
            System.out.println(runoobs[i]);
        }
      System.out.println("for-each");
        for (String obj:runoobs){
            System.out.print(obj+"\n");
        }

        //也可以通过数组列表进行迭代遍历打印元素
        dieDaiPrintArray();
    }

    /**
     * 也可以通过数组列表进行迭代遍历打印元素
     */
    static void dieDaiPrintArray()
    {
        ArrayList<String> runoobs = new ArrayList<String>();
        runoobs.add("www.");
        runoobs.add("runoob");
        runoobs.add(".com");
        for (Iterator<String> iterator = runoobs.iterator(); iterator.hasNext(); System.out.println(iterator.next())) {

        }
    }
}
