package my.arrays;

/**
 * 在 java 中找到重复的元素
 * 数组中有2个以上相同时，计数器变大时，要都输出里应该改==为>=
 * 查找不重复元素：finNotDupicateInArray
 */
public class RepeatArrays {
    public static void main(String[] args) {
        int[] my_array = {1, 2, 5, 5, 6, 6, 7, 2, 9, 2};
        findDupicateInArray(my_array);
        findNotDupicateInArray(my_array);

    }

    public static void findDupicateInArray(int[] a) {
        int count = 0;
        for (int j = 0; j < a.length; j++) {
            for (int k = j + 1; k < a.length; k++) {
                if (a[j] == a[k]) {
                    count++;
                    //System.out.println("count" + count);
                }
            }
            if (count == 1)
                System.out.println("重复元素 : " + a[j]);
            count = 0;
        }
    }

    public static void findNotDupicateInArray(int[] a) {
        int count = 0;
        for (int j = 0; j < a.length; j++) {
            for (int k = 0; k < a.length; k++) {  //int k =j+1;k<a.length;k++改成int k=0;k<a.length;k++
                if (a[j] == a[k]) {
                    count++;
                   // System.out.println("count:"+count);
                }
            }
            if (count == 1)
                System.out.println("不重复元素 : " + a[j]);
            count = 0;
        }
    }
}
