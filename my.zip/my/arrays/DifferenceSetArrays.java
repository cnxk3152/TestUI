package my.arrays;

import java.util.ArrayList;

/**
 * 使用 removeAll () 方法来计算两个数组的差集
 * 1、并集
 * 对于两个给定集合A、B，由两个集合所有元素构成的集合，叫做A和B的并集。
 * 记作：AUB  读作“A并B”
 * 例： {3,5}U{2,3,4,6}= {2,3,4,5,6}
 * 2、交集
 * 对于两个给定集合A、B，由属于A又属于B的所有元素构成的集合，叫做A和B的交集。
 * 记作： A∩B   读作“A交B”
 * 例： A={1,2,3,4,5}，B={3,4,5,6,8}，A∩B={3,4,5}
 * 3、差集
 * 记A，B是两个集合，则所有属于A且不属于B的元素构成的集合，叫做集合A减集合B(或集合A与集合B之差)，类似地，对于集合A、B，把集合{x∣x∈A,且x∉B}叫做A与B的差集。
 * 记作：B-A
 * 4、补集
 * 一般地，设S是一个集合，A是S的一个子集，由S中所有不属于A的元素组成的集合，叫做子集A在S中的绝对补集。
 * 记作：∁UA，包括三层含义：
 * 1）A是U的一个子集，即A⊊U;
 * 2）∁UA表示一个集合，且∁UA⊊U;
 * 3）∁UA是由U中所有不属于A的元素组成的集合，∁UA与A没有公共元素，U中的元素分布在这两个集合中。
 * 举例：全集为｛1,2,3,4,5｝ 那么｛1,2｝的补集就是｛3,4,5｝
 * 1、并集
 * 对于两个给定集合A、B，由两个集合所有元素构成的集合，叫做A和B的并集。
 * 记作：AUB  读作“A并B”
 * 例： {3,5}U{2,3,4,6}= {2,3,4,5,6}
 * 2、交集
 * 对于两个给定集合A、B，由属于A又属于B的所有元素构成的集合，叫做A和B的交集。
 * 记作： A∩B   读作“A交B”
 * 例： A={1,2,3,4,5}，B={3,4,5,6,8}，A∩B={3,4,5}
 * 3、差集
 * 记A，B是两个集合，则所有属于A且不属于B的元素构成的集合，叫做集合A减集合B(或集合A与集合B之差)，类似地，对于集合A、B，把集合{x∣x∈A,且x∉B}叫做A与B的差集。
 * 记作：B-A
 * 4、补集
 * 一般地，设S是一个集合，A是S的一个子集，由S中所有不属于A的元素组成的集合，叫做子集A在S中的绝对补集。
 * 记作：∁UA，包括三层含义：
 * 1）A是U的一个子集，即A⊊U;
 * 2）∁UA表示一个集合，且∁UA⊊U;
 * 3）∁UA是由U中所有不属于A的元素组成的集合，∁UA与A没有公共元素，U中的元素分布在这两个集合中。
 * 举例：全集为｛1,2,3,4,5｝ 那么｛1,2｝的补集就是｛3,4,5｝
 * ===============================================================================================================
 * 1、并集：以属于A或属于B的元素为元素的集合称为A与B的并（集），记作A∪B（或B∪A），读作“A并B”（或“B并A”），即A∪B={x|x∈A,或x∈B} 。
 *
 * 2、交集： 以属于A且属于B的元素为元素的集合称为A与B的交（集），记作A∩B（或B∩A），读作“A交B”（或“B交A”），即A∩B={x|x∈A,且x∈B}
 *
 * 3、补集：属于全集U不属于集合A的元素组成的集合称为集合A的补集，记作CuA，即CuA={x|x∈U,且x不属于A}。
 *
 * 扩展资料
 *
 * 摩根定律，又叫反演律，用文字语言可以简单的叙述为：两个集合的交集的补集等于它们各自补集的并集，两个集合的并集的补集等于它们各自补集的交集。
 *
 * 若集合A、B是全集U的两个子集，则以下关系恒成立：
 *
 * （1）∁U（A∩B）=（∁UA）∪（∁UB），即“交之补”等于“补之并”；
 *
 * （2）∁U（A∪B）=（∁UA）∩（∁UB），即“并之补”等于“补之交”。
 */
public class DifferenceSetArrays {
    public static void main(String[] args)  {
        ArrayList objArray = new ArrayList();
        ArrayList objArray2 = new ArrayList();
        objArray2.add(0,"common1");
        objArray2.add(1,"common2");
        objArray2.add(2,"notcommon");
        objArray2.add(3,"notcommon1");
        objArray.add(0,"common1");
        objArray.add(1,"common2");
        objArray.add(2,"notcommon2");
        System.out.println("array1 的元素" +objArray);
        System.out.println("array2 的元素" +objArray2);
        //objArray.removeAll(objArray2);
        objArray2.removeAll(objArray);
       // System.out.println("array1 与 array2 数组差集为："+objArray);
        System.out.println("array2 与 array1 数组差集为："+objArray2);
    }
}
