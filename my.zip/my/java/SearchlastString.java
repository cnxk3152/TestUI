package my.java;

/***
 * indexOf() 方法在字符串中查找子字符串出现的位置，如果存在返回字符串出现的位置（第一位为0），如果不存在返回 -1：
 * lastIndexof()最后出现的位置
 */
public class SearchlastString {
    public static void main(String[] args)
    {
        String strOrig="Hello world ,Hello Runoob";
        int lastIndex=strOrig.lastIndexOf("Runoob");
        if(lastIndex==-1)
        {
            System.out.println("没有找到字符串 Runnoob");
        }else
        {
            System.out.println("Runoob 字符串最后出的位置："+lastIndex);
        }

        System.out.println("=======查找第二例方法====");
        MSearchString();
    }



    public static void MSearchString()
    {
        String Str1 = "https://www.csdn.net.csdn.net/" ;
        String Str2 = "csdn",Str3 = "net" ;

        System.out.println("n第一次的位置："+ Str1.indexOf( "n" ) ) ;//第一位以0开始计算，比如abcd的顺序是0123

        System.out.println("n最后的位置：" + Str1.lastIndexOf( "n" ) ) ;
        System.out.println("字符串Str2【"+ Str2 +"】最后的位置：" + Str1.lastIndexOf( Str2 ) ) ;

        System.out.println("从第16个位置开始，n第一次的位置：" + Str1.indexOf( "n", 16 ) ) ;//虽然从10开始，但是返回值依然是从开始计算
        System.out.println("从第15个位置开始，字符串Str2【" + Str2 +"】第一次的位置：" + Str1.indexOf( Str2, 15 )) ;
        System.out.println("字符串Str3【"+ Str3 +"】最后的位置：" + Str1.lastIndexOf( Str3 )) ;

    }
}
