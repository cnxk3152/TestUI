package my.java;

/**
 * 通过 "+" 操作符和StringBuffer.append() 方法来连接字符串，并比较其性能
 */
public class StringConcatenate {
    public static void main(String[] args){
        long startTime = System.currentTimeMillis();
        for(int i=0;i<5000;i++){
            String result = "This is"
                    + "testing the"
                    + "difference"+ "between"
                    + "String"+ "and"+ "StringBuffer";
        }
        long endTime = System.currentTimeMillis();
        System.out.println("字符串连接"
                + " - 使用 + 操作符 : "
                + (endTime - startTime)+ " ms");
        long startTime1 = System.currentTimeMillis();
        for(int i=0;i<5000;i++){
            StringBuffer result = new StringBuffer();
            result.append("This is");
            result.append("testing the");
            result.append("difference");
            result.append("between");
            result.append("String");
            result.append("and");
            result.append("StringBuffer");
        }
        long endTime1 = System.currentTimeMillis();
        System.out.println("字符串连接"
                + " - 使用 StringBuffer : "
                + (endTime1 - startTime1)+ " ms");

        System.out.println("==========ADD StringBuffer.append compare===============");
        MAddStringBuffer();

        System.out.println("========Modify string add StringBuffer compare=====================");
        MAddStringBufferModify();
    }

    /**
     * 例扩展认知：+"为每个字符串变量赋值，公用一个内值，占用一份内存空间；"StringBuffer"每次新建一个新对象，内存分配新的空间，新分配5000份内存空间
     */
    public static void MAddStringBuffer()
    {
        long startTime = System.currentTimeMillis();
        String[] strArr = new String[500];
        for(int i=0;i<500;i++){
            String result = "This is";
            strArr[i]=String.valueOf(result.hashCode());
        }
        long endTime = System.currentTimeMillis();
        System.out.println("字符串连接"
                + " - 使用 + 操作符 : "
                + (endTime - startTime)+ " ms");
        System.out.println(strArr[0]+"\n"+strArr[1]+"\n"+strArr[2]);
        long startTime1 = System.currentTimeMillis();
        for(int i=0;i<500;i++){
            StringBuffer result = new StringBuffer();
            result.append("This is");
            strArr[i]=String.valueOf(result.hashCode());
        }
        long endTime1 = System.currentTimeMillis();
        System.out.println("字符串连接"
                + " - 使用 StringBuffer : "
                + (endTime1 - startTime1)+ " ms");
        System.out.println(strArr[0]+"\n"+strArr[1]+"\n"+strArr[2]);
    }

    /**
     * 附上另一种角度的性能分析，当需要对字符串对象的长度进行变化时，用 + 拼接的性能在循环时就会慢的慢的多，实际上 + 号拼接字符串也是通过 StringBuild 或 StringBuffer 实现的，但当进行频繁的修改本身时，+ 拼接会比直接用方法拼接产生更多的中间垃圾对象，耗用更多的内存，因此更推荐使用 StringBuild。其实我认为上述案例的性能分析是没有意义的，如果明确了要拼接的字符串的话，完全可以直接使用两种如下代码：
     *
     * result =result +  "This is esting the difference between String and StringBuffer ";
     * 或
     * result.append("This is esting the difference between String and StringBuffer" );
     */
    public static void MAddStringBufferModify()
    {
        String result1 = null;
        StringBuffer result = new StringBuffer();
        long startTime = System.currentTimeMillis();
        for(int i=0;i<5000;i++){
            result1 += "This is"
                    + "testing the"
                    + "difference"+ "between"
                    + "String"+ "and"+ "StringBuffer";
        }
        long endTime = System.currentTimeMillis();
        System.out.println("字符串连接"
                + " - 使用 + 操作符 : "
                + (endTime - startTime)+ " ms");
        long startTime1 = System.currentTimeMillis();
        for(int i=0;i<5000;i++){

            result.append("This is");
            result.append("testing the");
            result.append("difference");
            result.append("between");
            result.append("String");
            result.append("and");
            result.append("StringBuffer");
        }
        long endTime1 = System.currentTimeMillis();
        System.out.println("字符串连接"
                + " - 使用 StringBuffer : "
                + (endTime1 - startTime1)+ " ms");
    }

}
