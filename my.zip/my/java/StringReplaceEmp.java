package my.java;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/***
 * 以下实例中我们使用 java String 类的 replace 方法来替换字符串中的字符：
 */
public class StringReplaceEmp {
    public static void main(String args[]){
        String str="Hello World";
        System.out.println( str.replace( 'H','W' ) );
        System.out.println( str.replaceFirst("He", "Wa") );
        System.out.println( str.replaceAll("He", "Ha") );

        System.out.println("=======正则表达式替换======");
        MZhengZe();
    }

    public static void MZhengZe()
    {
        String str="Hello World";
        String regEx= "[abcdH]";
        String reStr= "";
        Pattern pattern   =   Pattern.compile(regEx);
        Matcher matcher   =   pattern.matcher(str); // 替换 a、b、c、d、H 为空，即删除这几个字母
        reStr = matcher.replaceAll("").trim();//replaceAll替换全部
        System.out.println( reStr );
    }
}
