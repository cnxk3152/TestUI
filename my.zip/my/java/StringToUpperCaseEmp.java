package my.java;

/***
 * String toUpperCase() 方法将字符串从小写转为大写
 */
public class StringToUpperCaseEmp {
    public static void main(String[] args) {
        String str = "string runoob";
        String strUpper = str.toUpperCase();
        System.out.println("原始字符串: " + str);
        System.out.println("转换为大写: " + strUpper);

        System.out.println("toLowerCase变小写");
        //================变小写
        String str2 = "STRING RUNOOB";
        String strLower = str2.toLowerCase();
        System.out.println("原始字符串: " + str2);
        System.out.println("转换为小写: " + strLower);




    }

}
