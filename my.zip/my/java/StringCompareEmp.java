package my.java;

public class StringCompareEmp{
    public static void main(String[] args)
    {
        String str="Hello World";
        String anotherString="hello world";
        Object objStr=str;
        Integer x=5;

        System.out.println("=========字符串比较========");
        /***
         * 以下实例中我们通过字符串函数 compareTo (string) ，
         * compareToIgnoreCase(String) 及
         * compareTo(object string) 来比较两个字符串，并返回字符串中第一个字母ASCII的差值。
         */
        System.out.println(str.compareTo(anotherString));
        System.out.println(str.compareToIgnoreCase(anotherString));//忽略大小写
        System.out.println(str.compareTo(objStr.toString()));

        System.out.println("=========数字比较========");
        /***
         * 如果指定的数与参数相等返回0。
         *
         * 如果指定的数小于参数返回 -1。
         *
         * 如果指定的数大于参数返回 1。
         */

        System.out.println(x.compareTo(3));
        System.out.println(x.compareTo(5));
        System.out.println(x.compareTo(8));
    }
}
