package my.java;

import java.util.Locale;

/**
 * format() 方法来格式化字符串，还可以指定地区来格式化：
 */
public class StringFormat {
    public static void main(String[] args){
        double e = Math.E;
        double MPI = Math.PI;
        System.out.format("%f%n", e);
        System.out.format(Locale.CHINA  , "%-10.4f%n%n", e);  //指定本地为中国（CHINA）

        System.out.format("%e%n",MPI);
        System.out.format(Locale.CHINA,"%-10.5f%n%n",MPI);
    }
}
