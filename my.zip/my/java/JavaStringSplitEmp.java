package my.java;

import java.util.Arrays;
import java.util.StringTokenizer;

/***
 * 使用了 split(string) 方法通过指定分隔符将字符串分割为数组
 */
public class JavaStringSplitEmp {
    public static void main(String args[]){

        String str = "www-runoob-com";
        String[] temp;
        String delimeter = "-";  // 指定分割字符
        temp = str.split(delimeter); // 分割字符串
        // 普通 for 循环
        for(int i =0; i < temp.length ; i++){
            System.out.println(temp[i]);
            System.out.println("");
        }

        System.out.println("------java for each循环输出的方法-----");
        String str1 = "www.runoob.com";
        String[] temp1;
        String delimeter1 = "\\.";  // 指定分割字符， . 号需要转义
        temp1 = str1.split(delimeter1); // 分割字符串
        for(String x :  temp1){
            System.out.println(x);
            System.out.println("");
        }

        System.out.println("=========Token=========");
        MToKen();
        System.out.println("=========string array last if null=========");
        MIfNull();
        System.out.println("=========Token2=========");
        MToKenString();
        System.out.println("=========Token Split compare=========");
        MSpTokenEmp();
        System.out.println("=========Token Split compare 2=========");
        MSpTokenEmpTwo();

    }

    /***
     * 其实在字符串分割时可以调用 StringTokenizer，实例化一个 StringTokenizer 的对象，通过 hasMoreTokens() 与 nextToken()进行判断并打印分割后的子字符串
     */
    public static void MToKen()
    {
        String str="www.runoob.com";
        // 实例化对象，并指向以 . 对 str 进行分割
        StringTokenizer str2=new StringTokenizer(str, ".");
        // 对 str2 遍历并打印子字符串；
        while(str2.hasMoreTokens()){
            System.out.println(str2.nextToken());
        }
    }

    public static void MIfNull()
    {
        String s1 = "123-123.2-1--";
        String[] ss1 =  s1.split("-");
        System.out.println(ss1.length);//3
        System.out.println(Arrays.toString(ss1));//[123, 123.2, 1]
        String s2 = "123--123.2-1--";
        String[] ss2 =  s2.split("-");
        System.out.println(ss2.length);//4
        System.out.println(Arrays.toString(ss2));//[123, , 123.2, 1]
    }

    /***
     * Java 中我们可以使用 StringTokennizer 设置不同分隔符来分隔字符串，默认的分隔符是：空格、制表符（\t）、换行符(\n）、回车符（\r）。
     *
     * 以下实例演示了 StringTokennizer 使用空格和等号来分隔字符串：
     */
    public static void MToKenString()
    {
        String str = "This is String , split by StringTokenizer, created by runoob";
        StringTokenizer st = new StringTokenizer(str);

        System.out.println("----- 通过空格分隔 ------");
        while (st.hasMoreElements()) {
            System.out.println(st.nextElement());
        }

        System.out.println("----- 通过逗号分隔 ------");
        StringTokenizer st2 = new StringTokenizer(str, ",");

        while (st2.hasMoreElements()) {
            System.out.println(st2.nextElement());
        }
    }

    /***
     * StringTokenizer和split方法还有一个很重要的区别就是：前者会以给定分割字符串的每个字符进行分割，而后者是以整个字符串进行切割
     */
    public static void MSpTokenEmp()
    {
        String str1 = "Hello";
        //字符串分割
        System.out.println("字符串使用 split 分割");
        System.out.print("将 Hello 从字符串 ll 处分割:");
        for(String temp:str1.split("ll")){
            System.out.print(temp+"  ");
        }
        System.out.println();
        System.out.println("------------------------------------");
        System.out.println("字符串使用 StringTokenizer 类进行分割");//实验心得 StringTokenizer 不保留空集
        StringTokenizer s = new StringTokenizer(str1, "l");
        System.out.print("将 Hello 从字符 l 处分割：");
        while(s.hasMoreElements()){
            System.out.print(s.nextElement()+"  ");
        }
        System.out.println();
    }
    public static void MSpTokenEmpTwo()
    {
        String str = "Hello,this is a test";
        System.out.println("使用split分割str");
        System.out.print("将str从字符串 el 处分割:");
        for(String temp:str.split("el")){
            System.out.print(temp+"  ");
        }
        System.out.println();
        System.out.println("------------------------------------");
        System.out.println("使用StringTokenizer类进行分割");
        StringTokenizer s = new StringTokenizer(str, "el");
        System.out.print("将str从字符e和l处分割：");
        while(s.hasMoreElements()){
            System.out.print(s.nextElement()+"  ");
        }
        System.out.println();
    }
}
