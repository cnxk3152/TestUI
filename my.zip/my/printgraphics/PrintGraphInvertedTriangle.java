package my.printgraphics;

/**
 * 打印倒立的三角形。
 */
public class PrintGraphInvertedTriangle {
    public static void main(String[] args) {
        //打印倒立的三角形
        for (int m = 1; m <= 4; m++) {
            //打印空格
            for (int n = 0; n <= m; n++) {
                System.out.print(" ");
            }
            //打印*
            for (int x = 1; x <= 7 -2 * (m - 1); x++) {
                System.out.print("*");
            }
            System.out.println();
        }
        System.out.println();
        MyPrintInvertedTriangle(4);
    }

    /**
     * 打印指定层数的倒立三角形：
     * @param size
     */
    public static void MyPrintInvertedTriangle(int size)
    {
        for (int i = size - 1; i >= 0; i--) {
            for (int j = 0; j < (size - 1) - i; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < 2 * i + 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
