package my.printgraphics;

public class PrintGraphMultiplicationTable {
    public static void main(String[] args) {
        for(int i=1;i<=9;i++) {
            for(int j=1;j<=i;j++) {
                System.out.print(j+"×"+i+"="+i*j+"\t");// \t 跳到下一个TAB位置
            }
            System.out.println();
        }
        System.out.println();
        MyMultipliactionTalbe();
        System.out.println("第三种方法：");
        ChengFa cf=new ChengFa();
        for(int f=1;f<=9;f++) {
            cf.chengshu(1, f);
            cf.xiangcheng();
        }
    }

    public static void MyMultipliactionTalbe()
    {
        for(int i=9;i>0;i--) {
            for(int j=1,k=10-i;j<=i;j++,k++) {
                System.out.print(j+"×"+k+"="+k*j+"\t");// \t 跳到下一个TAB位置
            }
            System.out.println();
        }
    }
}

/**
 * 自己写的类
 */
class ChengFa
{
    public int a;
    public int b;

    public ChengFa() {
    }

    public void chengshu(int aa, int bb) {
        a = aa;
        b = bb;
    }

    public void xiangcheng() {
        int c;
        c = 10 - b;
        for (int d = 1; d <= c; d++) {
            System.out.print(a + "*" + b + "=" + (a * b) + " ");
            if ((a * b) < 10) {
                System.out.print(" ");
            }
            a++;
            b++;
        }
        System.out.print("\n");
    }
}
