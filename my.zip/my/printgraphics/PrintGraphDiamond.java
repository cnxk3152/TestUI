package my.printgraphics;

public class PrintGraphDiamond {
    public static void main(String[] args) {
        MyprintOne(8); // 输出 8 行的菱形
        MyPrintSymmetric(8);
        MyPrintExtract(8);
    }

    public static void MyprintOne(int size) {
        if (size % 2 == 0) {
            size++; // 计算菱形大小
        }
        for (int i = 0; i < size / 2 + 1; i++) {
            for (int j = size / 2 + 1; j > i + 1; j--) {
                System.out.print(" "); // 输出左上角位置的空白
            }
            for (int j = 0; j < 2 * i + 1; j++) {
                System.out.print("*"); // 输出菱形上半部边缘
            }
            System.out.println(); // 换行
        }
        for (int i = size / 2 + 1; i < size; i++) {
            for (int j = 0; j < i - size / 2; j++) {
                System.out.print(" "); // 输出菱形左下角空白
            }
            for (int j = 0; j < 2 * size - 1 - 2 * i; j++) {
                System.out.print("*"); // 输出菱形下半部边缘
            }
            System.out.println(); // 换行
        }
    }

    /**
     * 1、另一种实现思路：利用菱形的对称，编写代码
     * symmetric对称
     * @param size
     */
    public static void MyPrintSymmetric(int size)
    {
        if (size % 2 == 0) {
            size++;// 计算菱形大小
        }

        //第一个和第二个for 循环中的代码一样。
        for (int i = 0; i < size / 2 + 1; i++) {
            for (int j = 0; j < (size / 2) - i; j++) {
                System.out.print(" ");// 输出左上角位置的空白
            }
            for (int j = 0; j < 2 * i + 1; j++) {
                System.out.print("&");// 输出菱形上左半部边缘
            }
            System.out.println();
        }
        for (int i = size / 2 - 1; i >= 0; i--) {
            for (int j = 0; j < (size / 2) - i; j++) {
                System.out.print(" ");// 输出菱形左下角空白
            }
            for (int j = 0; j < 2 * i + 1; j++) {
                System.out.print("&");// 输出菱形下半部边缘
            }
            System.out.println();
        }
    }

    /**
     * 代码抽取：抽取重复的代码片段到方法 printLint(...) 中
     * extract代码抽取 three third 3 第三
     * @param size
     */
    public static void MyPrintExtract(int size)  //
    {
        if (size % 2 == 0) {
            size++;// 计算菱形大小
        }
        //第一个和第二个for 循环中的代码一样。
        for (int i = 0; i < size / 2 + 1; i++) {
            printLine(size, i);
        }
        for (int i = size / 2 - 1; i >= 0; i--) {
            printLine(size, i);
        }
    }
        public static void printLine(int size, int i) {
        for (int j = 0; j < (size / 2) - i; j++) {
            System.out.print(" ");// 输出菱形左下角空白
        }
        for (int j = 0; j < 2 * i + 1; j++) {
            System.out.print("$");// 输出菱形下半部边缘
        }
        System.out.println();
    }


}
