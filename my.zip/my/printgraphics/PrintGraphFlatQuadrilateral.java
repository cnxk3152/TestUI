package my.printgraphics;

/**
 * 输出平行四边形
 */
public class PrintGraphFlatQuadrilateral {
    public static void main(String[] args) {
        //外层循环 每次打出一个*
        for (int i = 1; i <= 5; i++) {
            //填充空格
            for (int j = 1; j <= 5 - i; j++) {
                System.out.print(" ");
            }
            //内层循环 每次打印一个*
            for (int k = 1; k <= 5; k++) {
                System.out.print("*");
            }
            System.out.println();
        }

        System.out.println();
        PrintCircle(5); // 输出半径为5的圆
    }

    /**
     * 输入出指定半径圆
     * @param r
     */
    public static void PrintCircle(int r) {
        for (int y = 0; y <= 2 * r; y += 2) {
            int x = (int) Math.round(r - Math.sqrt(2 * r * y - y * y));
            int len = 2 * (r - x);
            // 圆左的空白
            for (int i = 0; i <= x; i++) {
                System.out.print(' ');
            }
            // 左半圆
            System.out.print('*');
            // 中间空白
            for (int j = 0; j <= len; j++) {
                System.out.print(' ');
            }
            // 右半圆
            System.out.println('*');
        }
    }

    /**
     * 指定层平形四边形
     * @param size
     */
    public static void PrintSetFlat(int size) {
        // 第一个和第二个for 循环中的代码一样。
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < (size - 1) - i; j++) {
                System.out.print(" "); // 输出左上角位置的空白
            }
            for (int j = 0; j < size; j++) {
                System.out.print("*"); // 输出菱形上左半部边缘
            }
            System.out.println();
        }
    }
}
