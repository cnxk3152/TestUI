package my.times;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 使用 Date 类及 SimpleDateFormat 类的 format(date) 方法来输出当前时间
 *
 * 利用生日获取当前的年龄:BirthdayObtainDateTime
 */
public class TimeObtain {
    public static void main(String[] args) throws ParseException
    {

        SimpleDateFormat sdf = new SimpleDateFormat();// 格式化时间
        sdf.applyPattern("yyyy-MM-dd HH:mm:ss a");// a为am/pm的标记
        Date date = new Date();// 获取当前时间
        System.out.println("现在时间：" + sdf.format(date)); // 输出已经格式化的现在时间（24小时制）

        BirthdayObtainDateTime();
    }

    static void BirthdayObtainDateTime() throws ParseException
    {
        SimpleDateFormat sdf =new SimpleDateFormat("yyyy年MM月dd日");
        //字符串变为时间Date类,解析p格式化f,pf
        String birthday = "1995年05月02日";
        Date d = sdf.parse(birthday);
        //获得时间毫秒值
        long myTime = d.getTime();
        //当前日期毫秒值
        long currentTime = new Date().getTime();
        System.out.println((currentTime-myTime)/1000/60/60/24/365);
    }
}
