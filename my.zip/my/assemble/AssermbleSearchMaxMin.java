package my.assemble;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 使用 Collections 类的 max() 和 min() 方法来获取List中最大最小值
 */
public class AssermbleSearchMaxMin {
    public static void main(String[] args) {
        //List list = Arrays.asList("one Two three Four five six one three Four".split(" "));
        List list = Arrays.asList("1 2 3 4 5 6 1 3 4".split(" "));
        System.out.println(list);
        System.out.println("最大值: " + Collections.max(list));
        System.out.println("最小值: " + Collections.min(list));
    }

}
