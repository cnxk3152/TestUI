package my.assemble;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 用 Collections 类的 rotate() 来循环移动元素，方法第二个参数指定了移动的起始位置
 * list<map> 这种格式，可以根据 map 中的某个字段排序，即自定义排序规则，实现如下：
 *
 * //排序
 * Collections.sort(list, new Comparator<Map<String,Object>>() {
 *   @Override
 *   public int compare(Map<String, Object> o1, Map<String, Object> o2) {
 *     //根据分数进行判断
 *     return (Float.valueOf((String)o2.get("score"))).compareTo(Float.valueOf((String)o1.get("score")));
 *   }
 * });
 */
public class AssermbleLoopRotateElement {
    public static void main(String[] args) {
        List list = Arrays.asList("one Two three Four five six".split(" "));
        System.out.println("List :"+list);
        Collections.rotate(list, 3);
        System.out.println("rotate: " + list);
    }
}
