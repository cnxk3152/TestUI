package my.assemble;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * Transformation 转换
 * 将一个数组转化为一个 List 对象，一般会想到 Arrays.asList() 方法，这个方法会返回一个 ArrayList 类型的对象。但是用这个对象对列表进行添加删除更新操作，就会报 UnsupportedOperationException 异常。
 *
 * public static <T> List<T> asList(T... a) {
 *     return new ArrayList<T>(a);
 * }这个 ArrayList 类并非 java.util.ArrayList 类，而是 Arrays 类的静态内部类！
 * public class Arrays {
 *     .......
 *
 *     private static class ArrayList<E> extends AbstractList<E>
 *         implements RandomAccess, java.io.Serializable
 *         {
 *         private static final long serialVersionUID = -2764017481108945198L;
 *         private final E[] a;
 *
 *         ArrayList(E[] array) {
 *             if (array==null)
 *             throw new NullPointerException();
 *             a = array;
 *         }
 *
 *         ......
 *     }
 * }
 * 再看这个静态内部类，存储数组元素的 a 变量是 final 类型的，由此判断，这个静态内部类是不能做任何内部元素的添加删除操作的！就跟 String 类一样，String 对象存储字符数组的变量也是有 final 修饰符的。因为一旦增加数组元素，这个数组容量已经定好的容器就无法装载增加的元素了。
 *
 * 内部类里面并没有 add、remove 方法，这个类继承的 AbstractList 类里面有这些方法。
 *
 * public abstract class AbstractList<E> extends AbstractCollection<E> implements List<E> {
 *     ........
 *
 *     public void add(int index, E element) {
 *         throw new UnsupportedOperationException();
 *     }
 *
 *     public E remove(int index) {
 *         throw new UnsupportedOperationException();
 *     }
 * }
 * 可以看出来，AbstractList 这个抽象类所定义的 add 和 remove 方法，仅仅是抛出了一个异常！为什么不是定义成一个抽象方法呢？然后让实现类去实现。
 *
 * 所以，如果是想将一个数组转化成一个列表并做增加删除操作的话，建议代码如下：
 *
 * List<WaiterLevel> levelList = new ArrayList<WaiterLevel>(Arrays.asList("a", "b", "c"));
 */
public class AssermbleArraysTransformationJihe {
    public static void main(String args[]) throws IOException {
        int n = 5;         // 5 个元素
        String[] name = new String[n];
        for(int i = 0; i < n; i++){
            name[i] = String.valueOf(i);
        }
        List<String> list = Arrays.asList(name);
        System.out.println();
        for(String li: list){
            String str = li;
            System.out.print(str + " ");
        }
    }
}
