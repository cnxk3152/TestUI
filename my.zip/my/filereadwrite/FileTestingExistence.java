package my.filereadwrite;

import java.io.File;

/**
 * 检测testing存在existence
 * 使用 File 类的 file.exists() 方法来检测文件是否存在
 */
public class FileTestingExistence {
    public static void main(String[] args) {
        File file = new File("./java.txt");
        System.out.println(file.exists());
    }
}
