package my.filereadwrite;

import java.io.*;

/**
 * 使用 BufferedWriter 类的 read 和 write 方法将文件内容复制到另一个文件
 */
public class FileCopy {
    public static void main(String[] args) throws Exception {
        BufferedWriter out1 = new BufferedWriter(new FileWriter("srcfile.txt"));
        out1.write("string to be copied\n成功了，高兴呀！！！");
        out1.close();
        InputStream in = new FileInputStream(new File("srcfile.txt"));
        OutputStream out = new FileOutputStream
                (new File("destnfile.txt"));
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
        BufferedReader in1 = new BufferedReader(new FileReader("destnfile.txt"));
        String str;
        while ((str = in1.readLine()) != null) {
            System.out.println(str);
        }
        in1.close();
    }

}
