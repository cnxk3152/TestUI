package my.filereadwrite;

import java.io.File;
import java.util.Date;

/**
 * 获取obtain
 * 使用 File 类的 file.lastModified() 方法来获取文件最后的修改时间
 */
public class FileObtainModifyTime {
    public static void main(String[] args) {
        File file = new File("java.txt");
        Long lastModified = file.lastModified();
        Date date = new Date(lastModified);
        System.out.println(date);
    }
}
