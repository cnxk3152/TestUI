package my.filereadwrite;

import jdk.internal.org.objectweb.asm.commons.StaticInitMerger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

/**
 * 使用 File 类的 createTempFile(String prefix, String suffix); 方法在默认临时目录来创建临时文件，参数 prefix 为前缀，suffix 为后缀：
 */
public class FileCreateTemp {
    public static void main(String[] args) throws Exception {
        File temp = File.createTempFile("testrunoobtmp", ".txt");
        System.out.println("文件路径: "+temp.getAbsolutePath());
        temp.deleteOnExit();
        BufferedWriter out = new BufferedWriter(new FileWriter(temp));
        out.write("aString");
        System.out.println("临时文件已创建:");
        out.close();

        MyCreateFileTemp();
    }

    /**
     *
     */
    public static void MyCreateFileTemp()
    {
        File f = null;

        try {

            // 创建临时文件
            f = File.createTempFile("tmp", ".txt", new File("e:/workspacejava"));

            // 输出绝对路径
            System.out.println("File path: "+f.getAbsolutePath());

            // 终止后删除临时文件
            f.deleteOnExit();

            // 创建临时文件
            f = File.createTempFile("tmp", null, new File("D:/"));

            // 输出绝对路径
            System.out.print("File path: "+f.getAbsolutePath());

            // 终止后删除临时文件
            f.deleteOnExit();

        } catch(Exception e) {

            // 如果有错误输出内容
            e.printStackTrace();
        }

    }
}
