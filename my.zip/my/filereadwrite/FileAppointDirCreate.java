package my.filereadwrite;

import java.io.File;

/**
 * 目录catalogue
 * File 类的 file.createTempFile() 方法在指定目录中创建文件
 */
public class FileAppointDirCreate {
    public static void main(String[] args) throws Exception {
        File file = null;
        File dir = new File("./src/my/filereadwrite");
        file = File.createTempFile
                ("JavaTemp", ".javatemp", dir);
        System.out.println(file.getPath());
    }
}
