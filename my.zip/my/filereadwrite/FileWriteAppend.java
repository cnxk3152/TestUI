package my.filereadwrite;

import java.io.*;

/**
 * 使用 filewriter 方法向文件中追加数据
 */
public class FileWriteAppend {
    public static void main(String[] args) throws Exception {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("filename"));
            out.write("aString1\n");
            out.close();
            out = new BufferedWriter(new FileWriter("filename",true));
            out.write("aString2\n追加成功了");
            out.close();
            BufferedReader in = new BufferedReader(new FileReader("filename"));
            String str;
            while ((str = in.readLine()) != null) {
                System.out.println(str);
            }
            in.close();
        }
        catch (IOException e) {
            System.out.println("exception occoured"+ e);
        }
        file_add("高兴的成功了");
    }

    /**
     * 文件追加数据
     * 原理就是将原文件数据先写进缓冲区，再在缓冲区追加数据最后保存
     * 也可以重新创建个备份文件记录原文件，再记录进缓冲区
     * 这里用第二种
     * 要用第一种，就只需要用一个字符串变量来记录备份，但是万一突然断电，缓冲区所有记录消失，还是更安全点好
     * @throws Exception
     */
    static void file_add(String str) throws Exception {
        //首先创建一个备份文件,并读取原文件写入备份数据
        File c = new File("filename");
        BufferedWriter c_w = new BufferedWriter(new FileWriter("filename"));
        BufferedReader a_r = new BufferedReader(new FileReader("a.txt"));
        String a_copy;
        while((a_copy=a_r.readLine())!=null) {
            c_w.write(a_copy);
            c_w.write("\n");
        }
        c_w.close();

        //再用备份文件先写入原文件缓冲区
        BufferedReader c_r = new BufferedReader(new FileReader("filename"));
        String c_str;
        BufferedWriter a_w = new BufferedWriter(new FileWriter("a.txt"));
        while((c_str=c_r.readLine())!=null) {
            a_w.write(c_str);
            a_w.write("\n");
        }

        //先不要写入，再把需要追加的参数数据写入缓冲区
        a_w .write(str);

        //然后写入
        a_w.close();

        //最后删除备份文件（也可以保留），删除需要中止该文件的所有数据流，最好所有的都结束
        a_r.close();
        a_w.close();
        c_r.close();
        c_w.close();
        c.delete();

    }
}
