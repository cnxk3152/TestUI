package my.filereadwrite;

import java.io.*;

/**
 * 使用 readLine() 方法来读取文件 test.log 内容，其中 test.log 文件内容为：
 * 自已提前准备的文件中，读取的中文输出会显示乱码
 */
public class FileRead {
    public static void main(String[] args)  {
        try {
            //TODO:自已提前准备的文件中，读取的中文输出会显示乱码, 如何是代码生成的话可以显示正常中文filewrite
            BufferedReader in = new BufferedReader(new FileReader("./src/my/readme"));
            String str;
            while ((str = in.readLine()) != null) {
                System.out.println(str);
            }
            System.out.println(str);
            System.out.println("中文好难");
        } catch (IOException e) {
        }
        FileReadWriteMe();
    }

    public static void FileReadWriteMe()
    {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("runoob.txt"));
            out.write("菜鸟教程");
            out.append("dasd");
            out.newLine();
            out.write("你好");
            out.flush();
            out.close();
            System.out.println("文件创建成功！");
            BufferedReader in = new BufferedReader(new FileReader("runoob.txt"));
            StringBuffer sb;
            while (in.ready()) {
                sb = (new StringBuffer(in.readLine()));
                System.out.println(sb);
            }
            in.close();
        } catch (IOException e) {
        }
    }
}
