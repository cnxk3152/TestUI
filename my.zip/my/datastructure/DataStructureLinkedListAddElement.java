package my.datastructure;

import java.util.LinkedList;

/**
 * 使用 LinkedList 类的 addFirst() 和 addLast() 方法在链表的开头和结尾添加元素
 */
public class DataStructureLinkedListAddElement {
    public static void main(String[] args) {
        LinkedList<String> lList = new LinkedList<String>();
        lList.add("1");
        lList.add("2");
        lList.add("3");
        lList.add("4");
        lList.add("5");
        System.out.println(lList);
        lList.addFirst("0");
        System.out.println(lList);
        lList.addLast("6");
        System.out.println(lList);
    }

}
