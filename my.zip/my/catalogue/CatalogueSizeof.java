package my.catalogue;

import java.io.File;
import org.apache.commons.io.FileUtils;//需要去apache.commons下载对应的库
/**
 *
 * 使用 File 类的 FileUtils.sizeofDirectory(File Name) 来获取目录的大小
 */
public class CatalogueSizeof {

    public static void main(String[] args) {
        long size = FileUtils.sizeOfDirectory(new File("./src/my/catalogue"));
        System.out.println("Size: " + size + " bytes");
    }
}
