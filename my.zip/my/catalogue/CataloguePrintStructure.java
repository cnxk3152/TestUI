package my.catalogue;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * 使用 File 类的 file.getName() 和 file.listFiles() 方法来打印目录结构
 * 使用 java 8 lambda 表达式，打印目录结构
 *  java 8 lambda 表达式，打印目录结构（移除目录判断：file.isDirectory()）
 */
public class CataloguePrintStructure {
    public static void main(String[] a) throws IOException {
        // showDir(1, new File("./src"));
       // printDir(1, new File("./src/com/helloworld"));
        printDirOne(1, new File("./src/my/arrays"));
    }

    static void showDir(int indent, File file) throws IOException {
        for (int i = 0; i < indent; i++)
            System.out.print('-');
        System.out.println(file.getName());
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (int i = 0; i < files.length; i++)
                showDir(indent + 4, files[i]);
        }
    }

    /**
     * 使用 java 8 lambda 表达式，打印目录结构
     *
     * @param indent
     * @param file
     */
    public static void printDir(int indent, File file) {
        Stream.generate(() -> '-').limit(indent).forEach(System.out::print);//打印缩进字符"-"
        System.out.println(file.getName());
        if (file.isDirectory()) {
            Arrays.asList(file.listFiles()).forEach(file2 -> printDir(indent + 2, file2));
        }

    }

    /**
     * * 1、使用 java 8 lambda 表达式，打印目录结构
     * * 2、移除目录判断：file.isDirectory()
     * * @param indent
     * * @param file
     * */
    public static void printDirOne(int indent, File file) {
        //打印缩进字符"-"
        Stream.generate(() -> '-').limit(indent).forEach(System.out::print);
        //打印目录或文件名称
        System.out.println(file.getName());
        //打印下级目录或文件名称
        Stream.of(Optional.ofNullable(file.listFiles()).orElse(new File[]{})).forEach(file2 -> printDir(indent + 2, file2));
    }

}
