package my.catalogue;

import java.io.File;

/**
 * 目录   catalogue
 * 使用 File 类的 mkdirs() 实现递归创建目录 ：
 */
public class CatalogueCreate {
    public static void main(String[] args) {
        String directories = ".\\src\\my\\Test";
        //String directories = "./src/my/TestC";
        File file = new File(directories);
        boolean result = file.mkdirs();
        System.out.println("Status = " + result);
    }
}
