package my.catalogue;

import java.io.File;

/**
 * ergodic 遍历
 * 使用 File 类的 dir.isDirectory() 和 dir.list() 方法来遍历目录
 */
public class CatalogueErgodicDir {
    public static void main(String[] argv) throws Exception {
        System.out.println("遍历目录");
        File dir = new File("./src/com"); //要遍历的目录
        visitAllDirsAndFiles(dir);
    }
    public static void visitAllDirsAndFiles(File dir) {
        System.out.println(dir);
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                visitAllDirsAndFiles(new File(dir, children[i]));
            }
        }
    }
}
