package my.catalogue;


import java.io.File;
import java.io.FilenameFilter;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * 搜索search
 * 在指定目录中，查找指定前缀的文件
 */
public class CatalogueSearch {
    public static void main(String[] args) {
        File dir = new File("./src/my");
        FilenameFilter filter = new FilenameFilter() {
            public boolean accept
                    (File dir, String name) {
                return name.startsWith("j");    //会区分大小写
            }
        };
        String[] children = dir.list(filter);
        if (children == null) {
            System.out.println("目录不存在或它不是一个目录");
        }
        else {
            for (int i=0; i < children.length; i++) {
                String filename = children[i];
                System.out.println(filename);
            }
        }
        System.out.println("==============");
        File dirFile = new File("./src/my/java");
        findFile4Prefix(dirFile, "D");
    }

    /**
     * * 在指定目录中，查找指定前缀的文件，并输出。     *
     * * @param dir
     * * @param prefix
     * */
    public static void findFile4Prefix(File dir, String prefix) {
        String[] fileNames = Optional.ofNullable(dir.list((file, fileName) -> fileName.startsWith(prefix))).orElse(new String[]{});
        Stream.of(fileNames).forEach(System.out::println);
    }

}
