package my.catalogue;

import java.io.File;
import java.io.FileFilter;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * 遍历 ergodic
 * 使用 File 类的 list 方法来遍历指定目录下的所有目录
 * 使用java8 lambda表达式编写代码：
 */
public class CatalogueAppointErgodic {
    public static void main(String[] args) {
        File dir = new File("./src/my/TestC");
        File[] files = dir.listFiles();
        FileFilter fileFilter = new FileFilter() {
            public boolean accept(File file) {
                return file.isDirectory();
            }
        };
        files = dir.listFiles(fileFilter);
        System.out.println(files.length);
        if (files.length == 0) {
            System.out.println("目录不存在或它不是一个目录或是空的");
        }
        else {
            for (int i=0; i< files.length; i++) {
                File filename = files[i];
                System.out.println(filename.toString());
            }
        }
        System.out.println("=============");
        File file = new File("./src");
        getAllDirectory(file);
        System.out.println("=============");
        File dir1 = new File("./src");
        File[] files1 = dir1.listFiles(file1 -> file.isDirectory());
        Stream.of(Optional.ofNullable(files1).orElse(new File[]{})).map(File::getName).forEach(System.out::println);

    }

    public static void getAllDirectory(File file) {
        //创建过滤器
        File[] f = file.listFiles(new GetAllDirectory());
        for (File f1 : f) {
            System.out.println(f1);
            //判断目录是否为空
            if (f1.length() != 0)
                getAllDirectory(f1);
        }
    }

}

class GetAllDirectory implements FileFilter {
    public boolean accept(File pathname) {
        // 去除所有非文件夹
        if (pathname.isDirectory()) {
            return true;
        }
        return false;
    }
}

