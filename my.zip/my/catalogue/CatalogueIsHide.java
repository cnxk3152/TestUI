package my.catalogue;

import java.io.File;

/**
 * 使用 File 类的 file.isHidden() 方法来判断文件是否隐藏
 * 隐藏 hide
 */
public class CatalogueIsHide {
    public static void main(String[] args) {
        File file = new File("./a.txt");
        System.out.println(file.isHidden());
    }
}
