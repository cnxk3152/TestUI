package my.catalogue;

import java.io.File;

/**
 * 使用 File 类的 file.getParent() 方法来获取文件的上级目录
 * obtain 获取  Get获得
 */
public class CatalogueObtainUpdirGet {
    public static void main(String[] args) {
        File file = new File("./src/my/catalogue/CatalogueDel.java");
        String strParentDirectory = file.getParent();
        System.out.println("文件的上级目录为 : " + strParentDirectory);
    }
}
