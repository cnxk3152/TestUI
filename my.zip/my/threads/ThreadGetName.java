package my.threads;

/**
 * 通过继承 Thread 类并使用 getName() 方法来获取当前线程名称
 */
public class ThreadGetName extends Thread {
    private int i=0;
    public void run() {
        for (int i = 0; i < 10; i++) {
            printMsg();
        }
    }
    public void printMsg() {
        Thread t = Thread.currentThread();
        String name = t.getName();
        System.out.println("name=" + name+" "+(i++));
    }
    public static void main(String[] args) {
        ThreadGetName tt = new ThreadGetName();
        tt.start();
        for (int i = 0; i < 10; i++) {
            tt.printMsg();
        }
    }

}
