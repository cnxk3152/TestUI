package com.helloworld;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class HelloWorld {
    public static void main(String[] args) throws IOException {
       // System.out.println("Helloworld");
        //从键盘输入
//        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
//        String s=br.readLine();
//        System.out.println(s);
        add(1,3);
    }

    public static void add(int a,int b)
    {
        int c;
        c=a+b;
        System.out.println("numberADD:"+c);
    }
}
